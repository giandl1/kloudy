package bean;

import java.util.ArrayList;

public class UtenteBean {
	String nome;
	String cognome;
	String username;
	String password;
	String piva;
	String email;
	String categoriaUtente;
	ArrayList<CartaBean> carte;
	ArrayList<IndirizzoBean> indirizzi;
	
	
	public ArrayList<CartaBean> getCarte() {
		return carte;
	}
	public void setCarte(ArrayList<CartaBean> carte) {
		this.carte = carte;
	}
	public ArrayList<IndirizzoBean> getIndirizzi() {
		return indirizzi;
	}
	public void setIndirizzi(ArrayList<IndirizzoBean> indirizzi) {
		this.indirizzi = indirizzi;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public String getPiva() {
		return piva;
	}
	public void setPiva(String piva) {
		this.piva = piva;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCategoriaUtente() {
		return categoriaUtente;
	}
	public void setCategoriaUtente(String categoriaUtente) {
		this.categoriaUtente = categoriaUtente;
	}
	
	
	


}

