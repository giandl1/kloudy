package bean;

public class IndirizzoBean {

	/**
	 * Variabili d'instanza
	 */
	private String indirizzo;
	private String citta;
	private String provincia;
	private int cap;
	private String nome;
	private String cognome;
	private String telefono;
	private String cliente;
	private int codice;

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public int getCodice() {
		return codice;
	}

	public void setCodice(int codice) {
		this.codice = codice;
	}

	/**
	 * Costruttore che inizializza le variabili d'instanza
	 * 
	 * @param indirizzo indirizzo dell'utente
	 * @param citt�     citt� relativa alla spedizione
	 * @param cap       cap relativo alla citt�
	 * @param nome      nome relativo alla spedizione
	 * @param cognome   cognome relativo alla spedizione
	 * @param telefono  numero di telefono relativo alla spedizione
	 */
	public IndirizzoBean(String indirizzo, String citta, int cap, String nome, String cognome, String telefono) {
		super();
		this.indirizzo = indirizzo;
		this.citta = citta;
		this.cap = cap;
		this.nome = nome;
		this.cognome = cognome;
		this.telefono = telefono;
	}

	/**
	 * Costruttore vuoto
	 */
	public IndirizzoBean() {

	}

	/**
	 * Ritorna la via e il numero civico dell'indirizzo
	 * 
	 * @return indirizzo
	 */
	public String getIndirizzo() {
		return indirizzo;
	}

	/**
	 * Setta la via e il numero civico dell'indirizzo
	 * 
	 * @param indirizzo nome via e numero civico dell'indirizzo
	 */
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	/**
	 * Restituisce la citt� dell'indirizzo
	 * 
	 * @return citt�
	 */
	public String getCitta() {
		return citta;
	}

	/**
	 * Setta la citt� dell'indirizzo
	 * 
	 * @param citt� citt� relativa alla spedizione
	 */
	public void setCitta(String citta) {
		this.citta = citta;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	/**
	 * Restituisce il cap dell'indirizzo
	 * 
	 * @return cap
	 */
	public int getCap() {
		return cap;
	}

	/**
	 * Setta il cap dell'indirizzo
	 * 
	 * @param cap codice avviamento postale
	 */
	public void setCap(int cap) {
		this.cap = cap;
	}

	/**
	 * Restituisce il nome del proprietario dell'indirizzo
	 * 
	 * @return nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * Setta il nome del proprietario dell'indirizzo
	 * 
	 * @param nome nome relativo alla spedizione
	 */

	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * Restiruisce il cognome del proprietario dell'indirizzo
	 * 
	 * @return
	 */
	public String getCognome() {
		return cognome;
	}

	/**
	 * Setta il cognome del proprietario dell'indirizzo
	 * 
	 * @param cognome cognome cognome relativo alla spedizione
	 */
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	/**
	 * Restituisce il numero di telefono dell'indirizzo
	 * 
	 * @return
	 */
	public String getTelefono() {
		return telefono;
	}

	/**
	 * Setta il numero di telefono dell'indirizzo
	 * 
	 * @param telefono numero di telefono della relativo alla spedizione dell'ordine
	 */
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Override
	public String toString() {
		return indirizzo + "," + citta + "," + cap + "," + nome + "," + cognome + "," + telefono;
	}

}
