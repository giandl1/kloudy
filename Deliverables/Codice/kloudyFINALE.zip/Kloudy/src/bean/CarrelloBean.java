package bean;

import java.util.ArrayList;

public class CarrelloBean {

	private ArrayList<ProdottoOrdineBean> products;

	public CarrelloBean() {
		products = new ArrayList<ProdottoOrdineBean>();
	}

	public String addProduct(ProdottoOrdineBean product, int daOrdinare, int disp) {
		int i;
		/*for (i = 0; i < products.size(); i++) {
			ProdottoOrdineBean p1 = products.get(i);
			if(!p1.getAutore().equalsIgnoreCase(product.getAutore())) {
				System.out.println("sono qui");
				return "autoreDiverso";
				 } 
		}	*/
		for (i = 0; i < products.size(); i++) {
			ProdottoOrdineBean p1 = products.get(i);
			if (p1.getId() == product.getId()) {
				if ((daOrdinare + p1.getQuantita()) <= disp) {
					p1.addQuantita(daOrdinare);
					return "ok";
				} else {
					return "erroreQuantita";
				}
			}
		}
		if (i >= products.size()) {

			product.setQuantita(daOrdinare);
			products.add(product);
		}
		return "ok";

	}

	public void deleteProduct(int id, int quantita) {
		for (ProdottoOrdineBean prod : products) {
			if (prod.getId() == id) {
				if (quantita == prod.getQuantita()) {
					products.remove(prod);
					break;
				} else {
					prod.setQuantita(prod.getQuantita() - quantita);
					break;
				}
			}
		}
	}

	public ArrayList<ProdottoOrdineBean> getProducts() {
		return products;
	}

	public double getCosto(String artista) {
		double costo = 0;
		int i;
		for (i = 0; i < products.size(); i++) {
			ProdottoOrdineBean prod = products.get(i);
			if(prod.getAutore().equalsIgnoreCase(artista))
			costo = costo + prod.getPrezzo();
		}
		return costo;
	}
	
	public double getCosto() {
		double costo = 0;
		int i;
		for (i = 0; i < products.size(); i++) {
			ProdottoOrdineBean prod = products.get(i);
			costo = costo + prod.getPrezzo();
		}
		return costo;
	}

	public void setProducts(ArrayList<ProdottoOrdineBean> products) {
		this.products = products;
	}
}
