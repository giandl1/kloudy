package control.gestioneModeratore;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.ProdottoModel;

/**
 * Servlet implementation class VerificaProdotto
 */
@WebServlet("/VerificaProdotto")
public class VerificaProdottoControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VerificaProdottoControl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
		HttpSession session = request.getSession();
		String user = (String) session.getAttribute("loggedIn");
		Object isMod = session.getAttribute("isMod");
		if (user == null || isMod == null) {
			String errore = "Accesso non consentito";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");

		} else {

		ProdottoModel model = new ProdottoModel();
		String action = request.getParameter("action");
		if(action == null || request.getParameter("id") == null) {
			String errore = "Parametri mancanti";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
			return;
		}
		int id = Integer.parseInt(request.getParameter("id"));
		String motivazione = request.getParameter("motivazione");
		if(!motivazione.matches("[A-Za-z �����]{5,100}"))
		{
			String errore = "Parametro non valido";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
			return;
		}
			if (action.equalsIgnoreCase("conferma")) {
				model.confermaProdotto(id);
			} else {
				model.rifiutaProdotto(id, motivazione);
			}
			RequestDispatcher disp = request.getRequestDispatcher("ListaProdottiDaVerificare");
			disp.forward(request, response);
		} } catch (SQLException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			String errore = "Parametro non valido";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		}  catch (ClassCastException e) {
			String errore = "Accesso non consentito";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		}

	} 

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
