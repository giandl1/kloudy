package control.gestioneModeratore;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.UtenteBean;
import model.UtenteModel;

/**
 * Servlet implementation class ListaUtentiControl
 */
@WebServlet("/ListaUtentiControl")
public class ListaUtentiControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListaUtentiControl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String user = (String) session.getAttribute("loggedIn");
		Object isMod = session.getAttribute("isMod");
		if (user == null || isMod == null) {
			String errore = "Accesso non consentito";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");

		} else {
			try {
				UtenteModel model = new UtenteModel();
				ArrayList<UtenteBean> users = model.doRetrieveAll();
				request.setAttribute("utenti", users);
				RequestDispatcher disp = request.getRequestDispatcher("listaUtenti.jsp");
				disp.forward(request, response);
			}
			catch(Exception e) { e.printStackTrace(); }
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
