package control.gestioneOrdini;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.ProdottoOrdineBean;
import bean.UtenteBean;
import model.ProdottoOrdineModel;

/**
 * Servlet implementation class ViewOrderServlet
 */
@WebServlet("/viewOrder")
public class VisualizzaOrdineControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VisualizzaOrdineControl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		UtenteBean user = (UtenteBean) session.getAttribute("loggedIn");
		if (user == null) {
			String errore = "Accesso non consentito";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");

		} else {
		ArrayList<ProdottoOrdineBean> products = new ArrayList<ProdottoOrdineBean>();
		ProdottoOrdineModel model = new ProdottoOrdineModel();
		int id = Integer.parseInt(request.getParameter("id"));
		try {
			products = model.doRetrieveByOrdine(id);
			request.removeAttribute("products");
			request.setAttribute("products", products);
			System.out.println(products.size());
			RequestDispatcher dispatcher = request.getRequestDispatcher("viewOrder.jsp");
			dispatcher.forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch(NumberFormatException e) {
			String errore = "Parametro non valido";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		}
	}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
