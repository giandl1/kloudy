package control.accesso;

import java.io.IOException;

import model.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.IndirizzoBean;
import bean.UtenteBean;

/**
 * Servlet implementation class SignupServlet
 */
@WebServlet("/Signup")
public class RegistrazioneControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegistrazioneControl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String nome = request.getParameter("nome"); // recupera tutti i dati inseriti nel form di signup
		String username = request.getParameter("username");
		String cognome = request.getParameter("cognome");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String piva = request.getParameter("piva");
		if (piva.equalsIgnoreCase(""))
			piva = null;
		String categoriaUtente = request.getParameter("ruolo");

		String address = request.getParameter("indirizzo");
		String citta = request.getParameter("citta");
		String provincia = request.getParameter("provincia");
		String cap = request.getParameter("cap");
		String telefono = request.getParameter("telefono");
		RequestDispatcher disp = request.getRequestDispatcher("/registrazione.jsp");
		RequestDispatcher disp2 = request.getRequestDispatcher("/home.jsp");

		if (nome == null || username == null || cognome == null || email == null || password == null
				|| categoriaUtente == null || address == null || citta == null || provincia == null || cap == null
				|| telefono == null) {
			String errore = "Dati del form mancanti";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		} else {

			if (!verificaDati(nome, username, cognome, email, password, address, citta, provincia, cap, telefono)) {
				String errore = "Dati del form errati";
				request.getSession().setAttribute("errore", errore);
				response.sendRedirect(request.getContextPath() + "/error.jsp");
			} else {
				try {
					UtenteBean utente = new UtenteBean(); // crea l'oggetto Utente con tutti i dati
					utente.setCategoriaUtente(categoriaUtente);
					utente.setCognome(cognome);
					utente.setEmail(email);
					utente.setNome(nome);
					utente.setPassword(password);
					utente.setUsername(username);
					utente.setPiva(piva);

					IndirizzoBean indirizzo = new IndirizzoBean();
					int cap2 = Integer.parseInt(cap);
					indirizzo.setCap(cap2);
					indirizzo.setCitta(citta);
					indirizzo.setCliente(username);
					indirizzo.setCognome(cognome);
					indirizzo.setNome(nome);
					indirizzo.setIndirizzo(address);
					indirizzo.setTelefono(telefono);
					indirizzo.setProvincia(provincia);

					UtenteModel model = new UtenteModel();
	

					if (model.countMail(utente)) {
						request.setAttribute("emailError", "error");
						disp.forward(request, response);
						return;
					}
					model.doSave(utente, indirizzo);
					disp2.forward(request, response);
					// salva il nuovo utente nel database tramite il metodo doSave
				} catch (Exception e) {
					e.printStackTrace();
					request.setAttribute("signupError", "Username gi� in uso");
					disp.forward(request, response);
				}
			}
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private boolean verificaDati(String nome, String username, String cognome, String email, String password, String address, String citta, 
			String provincia, String cap, String telefono) {
		if(email.matches("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}"))
			System.out.println("emailok");
		if(cap.matches("[0-9]{5}"))
			System.out.println("capok");
		if(telefono.matches("[0-9]{10}"))
			System.out.println("telok");
		if(nome.length() >= 3 && nome.length()<=20 && cognome.length()>=3 && cognome.length()<=20 && email.matches("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}")
				&& password.length() >= 6 && password.length()<= 20 && address.length()>=4 && address.length()<=40 &&
				citta.length()>=3 && citta.length()<=40 && provincia.length()>=2 && provincia.length()<=30 && cap.matches("[0-9]{5}") &&
				telefono.matches("[0-9]{10}"))
			return true;
		return false;
	}

}
