package control.accesso;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.ModeratoreBean;
import bean.UtenteBean;
import model.CartaModel;
import model.IndirizzoModel;
import model.ModeratoreModel;
import model.UtenteModel;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginControl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("uname") == null || request.getParameter("psw") == null)
			return;
		UtenteModel model = new UtenteModel();
		ModeratoreModel modelMod = new ModeratoreModel();
		CartaModel modelCarta = new CartaModel();
		IndirizzoModel modelInd = new IndirizzoModel();
		String uname = request.getParameter("uname");
		String psw = request.getParameter("psw");
		if(uname==null || psw==null) {
			response.sendRedirect("home.jsp");
			return;
		}
		try {
		UtenteBean user = model.doRetrieveByKey(uname);
		if( user != null && user.getUsername()!=null)
		{
			if(user.getPassword().equals(psw))
			{
				HttpSession session = request.getSession();
				UtenteBean logged = (UtenteBean) session.getAttribute("loggedIn");
				if(logged==null) {
					user.setCarte(modelCarta.doRetrieveAllByUsername(user.getUsername()));
					user.setIndirizzi(modelInd.doRetrieveAllByUsername(user.getUsername()));
					session.setAttribute("loggedIn", user);
				}
				if(user.getCategoriaUtente().equalsIgnoreCase("artista")) {
					String isAdmin = (String) session.getAttribute("isArtista");
					if(isAdmin==null) {
						session.setAttribute("isArtista", "yes");
					}
				}
				
			}
			else {
				String errore = "Username o password non valida";
				request.getSession().setAttribute("errore", errore);
				response.sendRedirect(request.getContextPath() + "/error.jsp");

			}
		}
		else
		{
			ModeratoreBean mod = modelMod.doRetrieveByKey(uname);
			if(mod != null && mod.getNickname()!=null && mod.getPwd().equals(psw))
			{
				HttpSession session = request.getSession();
				String logged = (String) session.getAttribute("loggedIn");
				if(logged==null) {
					System.out.println("sono qui");
					session.setAttribute("loggedIn", mod.getNickname());
					System.out.println("sessione salvata");
				}
				
				String isMod = (String) session.getAttribute("isMod");
					if(isMod==null) {
						session.setAttribute("isMod", "yes");
					}
				}
			else
			{
				String errore = "Username o password invalida";
				request.getSession().setAttribute("errore", errore);
				response.sendRedirect(request.getContextPath() + "/error.jsp");			}
				
			}
		RequestDispatcher disp = request.getRequestDispatcher("home.jsp");


		disp.forward(request, response);
		}
		
		
		
		catch(Exception e)
		{

			String error = (String) request.getAttribute("error");
			if(error==null) {
				request.setAttribute("error", "Username o password invalida");

			}
			e.printStackTrace();
		}
	
	}

}
