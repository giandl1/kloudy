package control.gestioneOrdiniArtista;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.UtenteBean;
import model.OrdineModel;

/**
 * Servlet implementation class ModificaStatoOrdineControl
 */
@WebServlet("/StatoOrdineInSped")
public class StatoOrdineInSpedControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StatoOrdineInSpedControl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		UtenteBean user = (UtenteBean) session.getAttribute("loggedIn");
		Object isArtista = session.getAttribute("isArtista");
		if (user == null || isArtista == null) {
			String errore = "Accesso non consentito";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");

		} else if (request.getParameter("id") == null || request.getParameter("corriere") == null
				|| request.getParameter("tracking") == null) {
			String errore = "Dati del form mancanti";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		} else {
			int id = Integer.parseInt(request.getParameter("id"));
			String corriere = request.getParameter("corriere");
			String tracking = request.getParameter("tracking");
			if (!verifica(corriere, tracking)) {
				String errore = "Dati del form errati";
				request.getSession().setAttribute("errore", errore);
				response.sendRedirect(request.getContextPath() + "/error.jsp");
			} else {
				try {
					OrdineModel model = new OrdineModel();
					model.setInSpedizione(id, corriere, tracking);
					RequestDispatcher disp = request.getRequestDispatcher("ListaOrdiniArtista");
					disp.forward(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	private boolean verifica(String corriere, String tracking) {
		if (corriere.matches("[A-Za-z ]{3,30}")&& tracking.matches("[A-Z]{4,30}"))
			return true;
		return false;
	}

}
