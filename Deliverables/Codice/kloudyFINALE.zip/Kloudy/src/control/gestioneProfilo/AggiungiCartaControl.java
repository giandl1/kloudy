package control.gestioneProfilo;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.CartaBean;
import model.CartaModel;
import bean.UtenteBean;

/**
 * Servlet implementation class CarteControl
 */
@WebServlet("/AggiungiCarta")
public class AggiungiCartaControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AggiungiCartaControl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		UtenteBean user = (UtenteBean) session.getAttribute("loggedIn");
		if (user == null) {
			String errore = "Accesso non consentito";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		} else if (request.getParameter("cardnumber") == null || request.getParameter("cardholder") == null
				|| request.getParameter("mesescadenza") == null || request.getParameter("annoscadenza") == null) {

			String errore = "Dati del form mancanti";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		} else {
			CartaBean carta = new CartaBean();
			String numCarta = request.getParameter("cardnumber");
			String nomeProprietario = request.getParameter("cardholder");
			String meseScadenza = request.getParameter("mesescadenza");
			String annoScadenza = request.getParameter("annoscadenza");
			String scadenza = meseScadenza + "/" + annoScadenza;
			String cvvS = request.getParameter("cardcvv");
			if (!verificaParametri(numCarta, scadenza, cvvS, nomeProprietario)) {
				String errore = "Dati del form errati";
				request.getSession().setAttribute("errore", errore);
				response.sendRedirect(request.getContextPath() + "/error.jsp");
			} else {
				int cvv = Integer.parseInt(cvvS);

				carta.setNomeProprietario(nomeProprietario);
				carta.setNumCarta(numCarta);
				carta.setScadenza(scadenza);
				carta.setCliente(user.getUsername());
				carta.setCvv(cvv);
				CartaModel model = new CartaModel();
				try {
					model.doSave(carta);

					user.setCarte(model.doRetrieveAllByUsername(user.getUsername()));
					RequestDispatcher disp = request.getRequestDispatcher("ListaCarte");
					disp.forward(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}
	}


	private boolean verificaParametri(String numeroCarta, String scadenza, String cvv, String nomeProprietario) {
		System.out.println(numeroCarta);
		System.out.println(scadenza);
		System.out.println(cvv);

		if ((numeroCarta.matches("[0-9]{16}")) && (scadenza.matches("[0-9]{1,2}[/]{1}[0-9]{2}"))
				&& (cvv.matches("[0-9]{3}") && nomeProprietario.matches("[A-Za-z ]{4,35}"))) {
			System.out.println("ok");
			return true;
		}
		return false;
	}

}
