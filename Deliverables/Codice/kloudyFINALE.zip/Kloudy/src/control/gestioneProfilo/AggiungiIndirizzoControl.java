package control.gestioneProfilo;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.IndirizzoBean;
import bean.UtenteBean;
import model.IndirizzoModel;

/**
 * Servlet implementation class CarteControl
 */
@WebServlet("/AggiungiIndirizzo")
public class AggiungiIndirizzoControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AggiungiIndirizzoControl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		UtenteBean user = (UtenteBean) session.getAttribute("loggedIn");
		if (user == null) {
			String errore = "Accesso non consentito";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		} else if (request.getParameter("nome") == null || request.getParameter("cognome") == null
				|| request.getParameter("indirizzo") == null || request.getParameter("telefono") == null
				|| request.getParameter("cap") == null || request.getParameter("citta") == null
				|| request.getParameter("provincia") == null) {

			String errore = "Dati del form mancanti";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		} else {
			IndirizzoBean indirizzo = new IndirizzoBean();
			String nome = request.getParameter("nome");
			String cognome = request.getParameter("cognome");
			String citta = request.getParameter("citta");
			String provincia = request.getParameter("provincia");
			String cap = request.getParameter("cap");
			String telefono = request.getParameter("telefono");
			String address = request.getParameter("indirizzo");

			if (!verificaParametri(nome, cognome, address, telefono, cap, citta, provincia)) {
				String errore = "Dati del form errati";
				request.getSession().setAttribute("errore", errore);
				response.sendRedirect(request.getContextPath() + "/error.jsp");
			} else {
				int cap2 = Integer.parseInt(cap);

				indirizzo.setCap(cap2);
				indirizzo.setCitta(citta);
				indirizzo.setProvincia(provincia);
				indirizzo.setNome(nome);
				indirizzo.setCognome(cognome);
				indirizzo.setTelefono(telefono);
				indirizzo.setIndirizzo(address);
				indirizzo.setCliente(user.getUsername());
				IndirizzoModel model = new IndirizzoModel();
				try {
					model.doSave(indirizzo);

					user.setIndirizzi(model.doRetrieveAllByUsername(user.getUsername()));
					RequestDispatcher disp = request.getRequestDispatcher("ListaIndirizzi");
					disp.forward(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}
	}
	private boolean verificaParametri(String nome, String cognome, String indirizzo, String telefono, String cap, String citta, String provincia) {


		if (nome.matches("[A-Za-z ]{3,20}") && cognome.matches("[A-Za-z ]{3,20}") && indirizzo.matches("[A-Za-z 0-9]{4,40}")
				&& telefono.matches("[0-9]{10}") && cap.matches("[0-9]{5}") && citta.matches("[A-Za-z ]{4,40}") && provincia.matches("[A-Za-z ]{2,30}")) {
			return true;
		}
		return false;
	}

}