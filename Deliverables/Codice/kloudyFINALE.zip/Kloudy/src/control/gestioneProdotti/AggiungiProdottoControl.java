package control.gestioneProdotti;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.ProdottoBean;
import bean.UtenteBean;
import model.ProdottoModel;

/**
 * Servlet implementation class AddProductServlet
 */
@WebServlet("/addProduct")
public class AggiungiProdottoControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AggiungiProdottoControl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		UtenteBean user = (UtenteBean) session.getAttribute("loggedIn");
		Object isArtista = session.getAttribute("isArtista");
		if (user == null || isArtista == null) {
			String errore = "Accesso non consentito";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");

		} else if (request.getParameter("categoria") == null 
				|| request.getParameter("titolo") == null || request.getParameter("descrizione") == null
				|| request.getParameter("data") == null || request.getParameter("prezzo") == null
				|| request.getParameter("dimensione") == null || request.getParameter("opera") == null
				|| request.getParameter("disponibilita") == null) {
			String errore = "Parametri mancanti";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		}

		else {
			String categoria = request.getParameter("categoria");
			String titolo = request.getParameter("titolo");
			String data = request.getParameter("data");
			String descrizione = request.getParameter("descrizione");
			String prezzo = request.getParameter("prezzo");
			String dimensione = request.getParameter("dimensione");
			String disponibilita = request.getParameter("disponibilita");
			String opera = request.getParameter("opera");
			String editore = request.getParameter("editore");
			String pagine = request.getParameter("pagine");
			String genere = request.getParameter("genere");
			String brani = request.getParameter("brani");
			String durata = request.getParameter("durata");
			if (categoria.equalsIgnoreCase("testi") && (editore == null
					|| pagine == null || genere == null)) {
				String errore = "Parametri mancanti";
				System.out.println("sono qui");
				request.getSession().setAttribute("errore", errore);
				response.sendRedirect(request.getContextPath() + "/error.jsp");
			} else if (categoria.equalsIgnoreCase("musica")
					&& (brani == null ||durata == null)) {
				String errore = "Parametri mancanti";
				request.getSession().setAttribute("errore", errore);
				response.sendRedirect(request.getContextPath() + "/error.jsp");
			} else {
				if(!verifica(titolo, data, descrizione,  opera) || ((categoria.equalsIgnoreCase("testi") && !verificaTesti(editore, genere, dimensione))
						|| (categoria.equalsIgnoreCase("musica") && !verificaAudio(durata, dimensione)) || (categoria.equalsIgnoreCase("digitalart") && !verificaArt(dimensione))))
					
				{
					String errore = "Dati del form errati";
					request.getSession().setAttribute("errore", errore);
					response.sendRedirect(request.getContextPath() + "/error.jsp");
				}
				else {
					try {	
				ProdottoBean product = new ProdottoBean();
				product.setAutore(user.getUsername());
				product.setTitolo(request.getParameter("titolo"));
				product.setDescrizione(request.getParameter("descrizione"));
				product.setDataCreazione(request.getParameter("data"));
				product.setPrezzo(Double.parseDouble(prezzo));
				product.setDimensione(request.getParameter("dimensione"));
				if (request.getParameter("brani") != null)
					product.setNumeroBrani(Integer.parseInt(request.getParameter("brani")));

				product.setDurata(request.getParameter("durata"));
				product.setEditore(request.getParameter("editore"));
				if (request.getParameter("pagine") != null)

					product.setNumeroPagine(Integer.parseInt(request.getParameter("pagine")));
				product.setCategoria(request.getParameter("categoria"));
				product.setVerificato(0);
				product.setOpera(request.getParameter("opera"));
				product.setGenere(request.getParameter("genere"));
				product.setDisponibilita(Integer.parseInt(disponibilita));
				product.setMotivazione(null);

				ProdottoModel model = new ProdottoModel();
			
					model.doSave(product);
					}	
				catch (NumberFormatException e) {
					String errore = "Dati del form errati";
					request.getSession().setAttribute("errore", errore);
					response.sendRedirect(request.getContextPath() + "/error.jsp");
					e.printStackTrace();
				} 	catch (Exception e) {
					
					e.printStackTrace(); }
			
				
				RequestDispatcher disp = request.getRequestDispatcher("ListaProdottiArtista");
				disp.forward(request, response);
			} }
		}
	}
	
	private boolean verificaArt(String dimensione) {

		if (dimensione.matches("[0-9]{1,3}x[0-9]{1,3}")) {
			return true;
		}
		return false;
	}
	
	private boolean verifica(String titolo, String data, String descrizione,  String opera) {

		if ((titolo.matches("[A-Za-z0-9 '�����]{4,50}") && data.matches("([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))") && descrizione.matches("[A-Za-z0-9 '�����]{4,100}")) && opera.matches("[A-Za-z 0-9]{4,40}.(jpg|png)")) {
			System.out.println("okGenerale");
			return true;
		}
		return false;
	}
	
	
	private boolean verificaTesti(String editore, String genere, String dimensione) {

		if ((editore.length() >=4 && editore.length() <= 30) && (genere.length() >= 4 && genere.length()<=20)
				&& dimensione.matches("[0-9]{1,2}MB")) {
			System.out.println("okTesti");
			return true;
		}
		return false;
	}
	
	private boolean verificaAudio(String durata, String dimensione) {

		if (durata.matches("[0-9]{2}:[0-9]{2}:[0-9]{2}") && dimensione.matches("[0-9]{1,2}MB")) {
			System.out.println("okAudio");
			return true;
		}
		return false;
	}


}
