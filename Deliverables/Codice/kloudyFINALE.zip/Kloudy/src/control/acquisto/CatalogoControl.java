package control.acquisto;

import java.io.IOException;
import model.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.ProdottoBean;

import javax.servlet.RequestDispatcher;

/**
 * Servlet implementation class Accessori
 */

//PER LE SERVLET VISTA E SOLE VALGONO GLI STESSI COMMENTI

@WebServlet("/Catalogo")
public class CatalogoControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CatalogoControl() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<ProdottoBean> products = new ArrayList<ProdottoBean>();
		ProdottoModel model = new ProdottoModel();
		String order = request.getParameter("sort");
		if (order == null)
			order = "codice";
		String tipo = request.getParameter("tipo");
		System.out.println(tipo);
		try {
			if (tipo.equalsIgnoreCase("digitalart")) {
				products = model.doRetrieveAllByType("digitalArt", order); // popola l'arraylist products attraverso il
																			// metodo
																			// del model, per tipo "accessori" e per
																			// ordine
																			// scelto dall'utente

				request.removeAttribute("products"); // elimina e riaggiunge l'attributo products alla richiesta per
														// aggiornare
														// la visualizzazione dei prodotti
				request.setAttribute("products", products);
				RequestDispatcher dispatcher = request.getRequestDispatcher("catalogoArt.jsp"); // delega la
																								// visualizzazione dei
																								// prodotti alla jsp
				dispatcher.forward(request, response);
			} else if (tipo.equalsIgnoreCase("testi")) {
				products = model.doRetrieveAllByType("testi", order); // se la richiesta non contiene il parametro
																		// dell'ordinamento, allora ordina default per
																		// codice

				request.removeAttribute("products"); // elimina e riaggiunge l'attributo products alla richiesta per
														// aggiornare
														// la visualizzazione dei prodotti
				request.setAttribute("products", products);
				RequestDispatcher dispatcher = request.getRequestDispatcher("catalogoTesti.jsp"); // delega la
																										// visualizzazione
																										// dei
																										// prodotti alla
																										// jsp
				dispatcher.forward(request, response);
			} else {
				products = model.doRetrieveAllByType("audio", order);

				request.removeAttribute("products"); // elimina e riaggiunge l'attributo products alla richiesta per
														// aggiornare
														// la visualizzazione dei prodotti
				request.setAttribute("products", products);
				RequestDispatcher dispatcher = request.getRequestDispatcher("catalogoAudio.jsp"); // delega la
																										// visualizzazione
																										// dei
																										// prodotti alla
																										// jsp
				dispatcher.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
