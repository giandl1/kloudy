package control.acquisto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import model.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.CarrelloBean;
import bean.ProdottoOrdineBean;
import bean.UtenteBean;
import bean.OrdineBean;

/**
 * Servlet implementation class CheckoutServlet
 */
@WebServlet("/ConfermaOrdine")
public class ConfermaOrdineControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ConfermaOrdineControl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		UtenteBean user = (UtenteBean) session.getAttribute("loggedIn");
		if (user == null) {
			String errore = "Accesso non consentito";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		} else {
			OrdineModel model = new OrdineModel();
			ProdottoOrdineModel model2 = new ProdottoOrdineModel();
			CarrelloBean cart = (CarrelloBean) session.getAttribute("cart");
			ArrayList<ProdottoOrdineBean> products = null;

			if (cart == null || cart.getProducts().size()==0 || request.getParameter("carta") == null || request.getParameter("indirizzo") == null) {
				String errore = "Parametri mancanti";
				request.getSession().setAttribute("errore", errore);
				response.sendRedirect(request.getContextPath() + "/error.jsp");
			}
			else {
			products = cart.getProducts();
			System.out.println("Num prodotti: " + products.size());
			ArrayList<OrdineBean> ordini = new ArrayList<OrdineBean>();
			ArrayList<String> artisti = new ArrayList<String>();
			int idCarta = Integer.parseInt(request.getParameter("carta"));
			int idIndirizzo = Integer.parseInt(request.getParameter("indirizzo"));
			for (int i = 0; i < products.size(); i++) {
				ProdottoOrdineBean prod = products.get(i);
				if (!presente(prod.getAutore(), artisti))
					artisti.add(prod.getAutore());
			}
			System.out.println("Num artisti: " + artisti.size());
			for (int i = 0; i < artisti.size(); i++) {
				OrdineBean ordine = new OrdineBean();
				ordine.setCliente(user.getUsername());
				ordine.setTotale(cart.getCosto(artisti.get(i)));
				Date data = new Date();
				ordine.setDataOrdine(data);
				ordine.setCarta(idCarta);
				ordine.setIndirizzo(idIndirizzo);
				ordine.setCorriere("");
				ordine.setTracking("");
				ordine.setStato("In attesa");
				ordine.setArtista(artisti.get(i));
				ordini.add(ordine);
			}
			System.out.println("Num ordini: " + ordini.size());
			ArrayList<OrdineBean> ordiniConId = new ArrayList<OrdineBean>();
			try {
				for (int i = 0; i < ordini.size(); i++) {
					int id = model.doSave(ordini.get(i));
					OrdineBean ordineID = ordini.get(i);
					ordineID.setId(id);
					ordiniConId.add(ordineID);
				}
				System.out.println("Num ordini con id: " + ordiniConId.size());

				for (int j = 0; j < ordiniConId.size(); j++) {
					for (int i = 0; i < products.size(); i++) {
						ProdottoOrdineBean prod = products.get(i);
						// System.out.println("Iterazione " + i + prod.getAutore() + " " +
						// ordiniConId.get(j).getArtista());
						if (prod.getAutore().equalsIgnoreCase(ordiniConId.get(j).getArtista()))
							model2.doSave(prod, ordiniConId.get(j).getId());

					}
				}
				session.removeAttribute("cart");
				RequestDispatcher disp = request.getRequestDispatcher("MyOrders");
				disp.forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	private boolean presente(String artista, ArrayList<String> artisti) {
		for (int i = 0; i < artisti.size(); i++) {
			String artista1 = artisti.get(i);
			if (artista1.equalsIgnoreCase(artista))
				return true;
		}
		return false;
	}

}
