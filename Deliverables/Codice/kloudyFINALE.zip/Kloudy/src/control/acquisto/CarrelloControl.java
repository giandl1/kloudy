package control.acquisto;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.CarrelloBean;
import bean.ProdottoOrdineBean;
import bean.ProdottoBean;
import model.*;
@WebServlet("/Cart")

public class CarrelloControl extends HttpServlet {

	private static final long serialVersionUID = 1L;
	static ProdottoModel model = new ProdottoModel();
	
	public CarrelloControl() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		CarrelloBean cart = (CarrelloBean)request.getSession().getAttribute("cart");  //verifica se c'� gia un carrello presente nella sessione, se non c'� lo crea vuoto
		if(cart == null) {
			cart = new CarrelloBean();
			request.getSession().setAttribute("cart", cart);
		}
		 	
		String action = request.getParameter("action");
		
		if(request.getParameter("id") == null || request.getParameter("quantity") == null || action==null) {
			String errore = "Parametri mancanti";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		}
		else if(!action.equalsIgnoreCase("addToCart") && (!action.equalsIgnoreCase("deleteFromCart"))){
			String errore = "Parametro non valido";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		} else {	
			
		try {
				if (action.equalsIgnoreCase("addToCart")) {      //se l'azione � addToCart, allora cerca il prodotto da aggiungere per ID, e lo aggiunge al carrello 
															 	 //con la quantit� selezionata dall'utente
					int id = Integer.parseInt(request.getParameter("id"));
					int quantita = Integer.parseInt(request.getParameter("quantity"));
					ProdottoBean prod = model.doRetrieveByKey(id);
					if(prod==null) {
						String errore = "Prodotto non presente nel database";
						request.getSession().setAttribute("errore", errore);
						response.sendRedirect(request.getContextPath() + "/error.jsp");
						return;
					}
					ProdottoOrdineBean product = new ProdottoOrdineBean();
					product.setId(prod.getCodice());
					product.setTitolo(prod.getTitolo());
					product.setAutore(prod.getAutore());
					product.setPrezzo(prod.getPrezzo());
					product.setOpera(prod.getOpera());
					product.setCategoria(prod.getCategoria());
					product.setQuantita(quantita);
					int disp = prod.getDisponibilita();
					String esito = cart.addProduct(product, quantita, disp);
					if(esito.equalsIgnoreCase("erroreQuantita")) {
						String errore = "Impossibile aggiungere la quantit� desiderata";
					request.getSession().setAttribute("errore", errore);
					response.sendRedirect(request.getContextPath() + "/error.jsp");
					return;
					}
				}
				else if (action.equalsIgnoreCase("deleteFromCart")) {
					int id = Integer.parseInt(request.getParameter("id"));
					int quantita = Integer.parseInt(request.getParameter("quantity"));
					cart.deleteProduct(id, quantita);
				} 
						
		 
		
		request.getSession().setAttribute("cart", cart);
		


		RequestDispatcher dispatcher = request.getRequestDispatcher("carrello.jsp"); 
		dispatcher.forward(request, response);
		} catch (SQLException e) {
			System.out.println("Error:" + e.getMessage());
		}  catch (NumberFormatException e) {
			String errore = "Parametro non valido";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		}
	} }

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
