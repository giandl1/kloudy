package control.acquisto;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import model.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.ProdottoBean;

/**
 * Servlet implementation class Search
 */
@WebServlet("/Search")
public class RicercaProdottoControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RicercaProdottoControl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String artista = request.getParameter("artista");
		if (artista == null) {
			String errore = "Parametri mancanti";
			request.getSession().setAttribute("errore", errore);
			response.sendRedirect(request.getContextPath() + "/error.jsp");
		} else {
			String order = request.getParameter("order");
			if (order == null || order.equalsIgnoreCase(""))
				order = "codice";
			ProdottoModel model = new ProdottoModel();
			ArrayList<ProdottoBean> products = new ArrayList<ProdottoBean>();

			try {
				products = model.searchByArtist(artista, order);

				request.removeAttribute("searchproducts");
				request.setAttribute("searchproducts", products);
				RequestDispatcher dispatcher = request.getRequestDispatcher("searchPage.jsp");
				dispatcher.forward(request, response);
			} catch (

			SQLException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
