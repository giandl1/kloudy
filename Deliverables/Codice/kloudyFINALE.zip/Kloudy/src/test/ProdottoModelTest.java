package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import bean.ProdottoBean;
import model.ProdottoModel;

public class ProdottoModelTest {
	private ProdottoBean prodotto;
	private MysqlDataSource ds;
	private ProdottoModel model;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		ds = new MysqlDataSource();
		ds.setURL("jdbc:mysql://localhost:3306/kloudy");
		ds.setUser("root");
		ds.setPassword("kloudy2019");
		model = new ProdottoModel(ds);
		prodotto = new ProdottoBean();
		prodotto.setCategoria("digitalArt");
		prodotto.setAutore("TitoFornasiero");
		prodotto.setDataCreazione("2019-02-03");
		prodotto.setDescrizione("opera di test");
		prodotto.setDimensione("12x30");
		prodotto.setDisponibilita(5);
		prodotto.setOpera("test.jpg");
		prodotto.setPrezzo(35);
		prodotto.setVerificato(0);
		prodotto.setTitolo("test");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testDoSave() throws Exception {
			int id = model.doSave(prodotto);
			assertNotNull(model.doRetrieveByKey(id));

	}

	@Test
	public void testDoRetrieveByKey() throws Exception {
		ProdottoBean prodotto = null;
			prodotto = model.doRetrieveByKey(1);
			assertNotNull(prodotto);
	}

	@Test
	public void testDoRetrieveByVerificato() throws Exception {
		ArrayList<ProdottoBean> prodotti = null;
			prodotti = model.doRetrieveByVerificato();
			assertNotNull(prodotti);
			assertEquals(0, prodotti.get(0).getVerificato());

	}

	@Test
	public void testDoDelete() throws Exception {
			int id = model.doSave(prodotto);
			model.doDelete(id);
			assertNull(model.doRetrieveByKey(id));

	}

	@Test
	public void testDoRetrieveAllByType() throws Exception{
		ArrayList<ProdottoBean> prodotti = null;
			prodotti = model.doRetrieveAllByType("digitalArt", "codice");
			assertNotNull(prodotti);
			assertEquals(2, prodotti.size());
			assertEquals("digitalArt", prodotti.get(0).getCategoria());

	}


@Test
  public void testDoRetrieveByUser() throws Exception {
    ArrayList<ProdottoBean> list = null;    
      list = model.doRetrieveByUser("AntonioManzini");
      assertNotNull(list);
      assertEquals(3, list.size());
  }

  @Test
  public void testSearchByArtist() throws Exception {
    ArrayList<ProdottoBean> list = null;    
      list = model.searchByArtist("Anto","codice");
      assertNotNull(list);
      assertEquals(2,list.size());
  }

  @Test
  public void testConfermaProdotto() throws Exception {
      model.confermaProdotto(7);      
      assertEquals(1, model.doRetrieveByKey(7).getVerificato());

  }

  @Test
  public void testRifiutaProdotto() throws Exception {

      model.rifiutaProdotto(8, "Prezzo non conforme");
      assertEquals("Prezzo non conforme",model.doRetrieveByKey(8).getMotivazione());
    }
  

  @Test
  public void testDoRetrieveByArtistVerificato() throws Exception {
    ArrayList<ProdottoBean> list = null;
      list = model.doRetrieveByArtistVerificato("AntonioManzini");
      assertNotNull(list);
      assertEquals(1, list.size());

  }


}
