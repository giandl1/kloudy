package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import bean.CartaBean;
import model.CartaModel;

public class CartaModelTest {
	private CartaBean carta;
	private String username;
	private MysqlDataSource ds;
	private CartaModel model;
	private int id;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		ds = new MysqlDataSource();
		ds.setURL("jdbc:mysql://localhost:3306/kloudy");
		ds.setUser("root");
		ds.setPassword("kloudy2019");
		username = "TitoFornasiero";
		model = new CartaModel(ds);
		carta = new CartaBean();
		carta.setCliente("gianluca");
		carta.setCvv(235);
		carta.setNomeProprietario("Tito Fornasiero");
		carta.setNumCarta("1111111111111111");
		carta.setScadenza("10/23");
		username = "TitoFornasiero";
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testDoSave() throws Exception{

			this.id = model.doSave(carta);
			System.out.println(id);
			assertNotNull(model.doRetrieveByKey(id));

	}

	@Test
	public void testDoRetrieveAllByUsername() throws Exception {
		ArrayList<CartaBean> carte = null;
			carte = model.doRetrieveAllByUsername(username);
			assertNotNull(carte);
			assertEquals(carte.get(0).getCliente(), username);
			assertEquals(1,carte.size());

	}

	@Test
	public void testDoDeleteByKey() throws Exception {
			id = model.doSave(carta);
			model.doDeleteByKey(id);
			assertNull(model.doRetrieveByKey(id));

	}

	@Test
	public void testDoRetrieveByKey() throws Exception {
		CartaBean carta = null;
			carta = model.doRetrieveByKey(12);
			assertNotNull(carta);
	}

}
