package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import bean.IndirizzoBean;
import bean.UtenteBean;
import model.UtenteModel;


public class UtenteModelTest {
	private UtenteBean utente;
	private static  MysqlDataSource ds;
	private static UtenteModel model;
	private IndirizzoBean indirizzo;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		ds = new MysqlDataSource();
		ds.setURL("jdbc:mysql://localhost:3306/kloudy");
		ds.setUser("root");
		ds.setPassword("kloudy2019");
		model = new UtenteModel(ds);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {

		utente = new UtenteBean();
		indirizzo = new IndirizzoBean();
		utente.setCategoriaUtente("appassionato");
		utente.setCognome("di lillo");
		utente.setNome("gianluca");
		utente.setEmail("lol@gmail.com");
		utente.setPassword("aaa111");
		utente.setUsername("gianluca123");
		indirizzo.setCap(81024);
		indirizzo.setCitta("Maddaloni");
		indirizzo.setProvincia("Caserta");
		indirizzo.setCognome("di lillo");
		indirizzo.setNome("gianluca");
		indirizzo.setCliente("gianluca123");
		indirizzo.setTelefono("3200781141");
		indirizzo.setIndirizzo("via lol 123");

	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testDoSave() throws Exception {
			model.doSave(utente, indirizzo);
			assertNotNull(model.doRetrieveByKey("gianluca123"));

	}

	@Test
	public void testDoRetrieveByKey() throws Exception {
		UtenteBean utente = null;

			utente = model.doRetrieveByKey("TitoFornasiero");
			assertNotNull(utente);

	}

	@Test
	public void testCountMail() throws Exception {
		boolean presente = false;
			presente = model.countMail(utente);
			assertEquals(true, presente);

	}

	@Test
	public void testDoRetrieveAll() throws Exception {
		ArrayList<UtenteBean> utenti = null;
			utenti = model.doRetrieveAll();
			assertNotNull(utenti);
	}

	@Test
	public void testDoDelete() throws Exception {
			UtenteBean utente = this.utente;
			utente.setUsername("testdelete");
			IndirizzoBean indirizzo = this.indirizzo;
			indirizzo.setCliente("testdelete");
			model.doSave(utente, indirizzo);
			model.doDelete("testdelete");
			assertNull(model.doRetrieveByKey("testdelete"));
	}

}
