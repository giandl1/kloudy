package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import bean.IndirizzoBean;
import model.IndirizzoModel;


public class IndirizzoModelTest {
	private MysqlDataSource ds;
	private IndirizzoBean indirizzo;
	private IndirizzoModel model;
	private String user;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		ds = new MysqlDataSource();
		ds.setURL("jdbc:mysql://localhost:3306/kloudy");
		ds.setUser("root");
		ds.setPassword("kloudy2019");
		model = new IndirizzoModel(ds);
		user = "TitoFornasiero";
		indirizzo = new IndirizzoBean();
		indirizzo.setCap(81024);
		indirizzo.setCitta("Maddaloni");
		indirizzo.setCliente(user);
		indirizzo.setCognome("di Lillo");
		indirizzo.setNome("Gianluca");
		indirizzo.setIndirizzo("Via Napoli 2");
		indirizzo.setProvincia("Caserta");
		indirizzo.setTelefono("3200781141");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testDoSave() throws Exception {
			int id = model.doSave(indirizzo);
			assertNotNull(model.doRetrieveByKey(id));

	}

	@Test
	public void testDoRetrieveAllByUsername() throws Exception {
		ArrayList<IndirizzoBean> indirizzo = null;
			indirizzo = model.doRetrieveAllByUsername(user);
			assertEquals(indirizzo.get(0).getCliente(), user);

	}

	@Test
	public void testRimuoviIndirizzo() throws Exception {
			int id = model.doSave(indirizzo);
			model.rimuoviIndirizzo(id);
			assertNull(model.doRetrieveByKey(id));
	}
	
	@Test
	public void testDoRetrieveByKey() throws Exception {
			IndirizzoBean address = model.doRetrieveByKey(1);
			assertNotNull(address);

	}


}
