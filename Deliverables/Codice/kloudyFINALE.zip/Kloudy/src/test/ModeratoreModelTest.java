package test;

import static org.junit.Assert.*;


import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import bean.ModeratoreBean;
import model.ModeratoreModel;

public class ModeratoreModelTest {

	private MysqlDataSource ds;
	private ModeratoreModel model;
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		ds = new MysqlDataSource();
		ds.setURL("jdbc:mysql://localhost:3306/kloudy");
		ds.setUser("root");
		ds.setPassword("kloudy2019");
		model = new ModeratoreModel(ds);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testDoRetrieveByKey() throws Exception {
		ModeratoreBean mod = null;
			mod = model.doRetrieveByKey("kloudymod");
			assertNotNull(mod);

	}

}
