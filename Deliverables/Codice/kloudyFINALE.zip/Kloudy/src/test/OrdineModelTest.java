package test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import bean.OrdineBean;
import model.OrdineModel;

public class OrdineModelTest {

	private MysqlDataSource ds;
	private OrdineModel model;
	private OrdineBean ordine;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		ds = new MysqlDataSource();
		ds.setURL("jdbc:mysql://localhost:3306/kloudy");
		ds.setUser("root");
		ds.setPassword("kloudy2019");
		model = new OrdineModel(ds);
		ordine = new OrdineBean();
		ordine.setCarta(12);
		ordine.setCliente("TitoFornasiero");
		ordine.setCorriere("Bartolino");
		ordine.setDataOrdine(new Date());
		ordine.setIndirizzo(1);
		ordine.setStato("Spedito");
		ordine.setTotale(30);
		ordine.setTracking("34567890");
		ordine.setArtista("TitoFornasiero");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testDoSave() throws Exception {
		int id = model.doSave(ordine);
		assertNotNull(model.doRetrieveByKey(id));

	}

	@Test
	public void testDoRetrieveAll() throws Exception {
		ArrayList<OrdineBean> ordini = model.doRetrieveAll("gianluca", "codice");
		assertEquals(ordini.get(0).getCliente(), "gianluca");

	}

	@Test
	public void testDoRetrieveByArtist() throws Exception {
		ArrayList<OrdineBean> ordini = model.doRetrieveByArtist("TitoFornasiero");
		assertEquals(ordini.get(0).getArtista(), "TitoFornasiero");

	}
	
	@Test
	public void testSetInSpedizione() throws Exception {
		model.setInSpedizione(1, "bartolini", "abcd");
		assertEquals("In spedizione", model.doRetrieveByKey(1).getStato());

	}
	
	public void testSetSpedito() throws Exception {
		model.setSpedito(1);
		assertEquals("Spedito", model.doRetrieveByKey(1).getStato());

	}

}
