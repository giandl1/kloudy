package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import bean.ProdottoOrdineBean;
import model.ProdottoOrdineModel;

public class ProdottoOrdineModelTest {
	private ProdottoOrdineBean prodotto;
	private MysqlDataSource ds;
	private ProdottoOrdineModel model;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		ds = new MysqlDataSource();
		ds.setURL("jdbc:mysql://localhost:3306/kloudy");
		ds.setUser("root");
		ds.setPassword("kloudy2019");
		model = new ProdottoOrdineModel(ds);
		prodotto = new ProdottoOrdineBean();
		prodotto.setAutore("TitoFornasiero");
		prodotto.setCategoria("digitalArt");
		prodotto.setId(1);
		prodotto.setOpera("Iariano.jpg");
		prodotto.setPrezzo(140);
		prodotto.setQuantita(1);
		prodotto.setTitolo("Paesaggio Iariano");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testDoSave() throws Exception {
			int id = model.doSave(prodotto, 1);
			assertNotNull(model.doRetrieveByKey(id));

	}

	@Test
	public void testDoRetrieveByOrdine() throws Exception {
			ArrayList<ProdottoOrdineBean> prodotti = model.doRetrieveByOrdine(2);
			assertEquals(2, prodotti.get(0).getCodiceOrdine());

	}
	
	@Test
	public void testDoRetrieveByKey() throws Exception {
		ProdottoOrdineBean prodotto = null;
			prodotto = model.doRetrieveByKey(1);
			assertNotNull(prodotto);

	}

}
