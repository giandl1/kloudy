package model;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import bean.CartaBean;

/**
 * Classe che gestisce la transazione delle carte di credito
 *
 */
public class CartaModel {
	private  DataSource ds;
	public CartaModel() {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	
	public CartaModel(DataSource ds) {
		this.ds = ds;
	}
	
	public synchronized int doSave(CartaBean carta)
			throws SQLException {

		if (carta==null) throw new IllegalArgumentException();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String insertSQLProd = "INSERT INTO carta" 
				+ " (dataScad, numero, proprietario, utente, cvv) VALUES (?, ?, ?, ?, ?)";
		int id = -1;

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQLProd, Statement.RETURN_GENERATED_KEYS);

			preparedStatement.setString(1, carta.getScadenza());
			preparedStatement.setString(2, carta.getNumCarta());
			preparedStatement.setString(3, carta.getNomeProprietario());
			preparedStatement.setString(4, carta.getCliente());
			preparedStatement.setInt(5, carta.getCvv());
			preparedStatement.executeUpdate();
			ResultSet rs = preparedStatement.getGeneratedKeys();
			rs.next();
			id = rs.getInt(1);

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		} 
		return id;
	}

	/**
	 * Metodo che legge le carte di credito presenti nel database collegate al
	 * nickname passato come parametro
	 * 
	 * @param nickname
	 * @pre nickname != null
	 * @post carte.size() > 0 se il cliente ha associato delle carte || carte.size()
	 *       == 0 se non ci sono associate delle carte al cliente
	 * @return carte
	 * @throws SQLException
	 */
	public synchronized ArrayList<CartaBean> doRetrieveAllByUsername(String nickname) throws SQLException {

		if (nickname == null) {
			throw new IllegalArgumentException();
		}

		ArrayList<CartaBean> carte = new ArrayList<CartaBean>();

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String insertSQLProd = "SELECT * FROM carta" + " WHERE utente = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQLProd);
			preparedStatement.setString(1, nickname);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				CartaBean bean = new CartaBean();
				bean.setCodice(rs.getInt("codice"));
				bean.setScadenza(rs.getString("dataScad"));
				String numero = rs.getString("numero");
				String numerosafe = numero.substring(0, 4) + "XXXXXXXX" + numero.substring(12, 16);
				bean.setNumCarta(numerosafe);
				bean.setNomeProprietario(rs.getString("proprietario"));
				bean.setCvv(rs.getInt("cvv"));
				bean.setCliente(rs.getString("utente"));

				carte.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return carte;
	}

	/**
	 * Metodo che rimuove una carta dal database
	 * 
	 * @param codice
	 * @pre codice >= 0
	 * @post la carta associata al codice passato come parametro viene rimossa dal
	 *       database
	 * @throws SQLException
	 */
	public synchronized void doDeleteByKey(int codice) throws SQLException {
		if (codice < 0) {
			throw new IllegalArgumentException();
		}
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String insertSQL = "DELETE FROM carta" + " WHERE codice = ?";
		try {
			try {
				connection = ds.getConnection();
				preparedStatement = connection.prepareStatement(insertSQL);
				preparedStatement.setInt(1, codice);
				preparedStatement.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}
	
	public synchronized CartaBean doRetrieveByKey(int codice) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		CartaBean carta = null;
		if(codice<0) throw new IllegalArgumentException();
		String selectSQL = "SELECT * FROM carta WHERE codice = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, codice);

			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				carta = new CartaBean();
				carta.setCodice(rs.getInt("codice"));
				carta.setCliente(rs.getString("utente"));
				carta.setNomeProprietario(rs.getString("proprietario"));
				carta.setCvv(rs.getInt("cvv"));
				carta.setScadenza(rs.getString("dataScad"));
				carta.setNumCarta(rs.getString("numero"));
			
			}
				
			}
	
		 finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return carta;
	}
	
	
	

}
