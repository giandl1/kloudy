package model;

import java.sql.Connection;

import bean.ProdottoBean;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class ProdottoModel {

	private  DataSource ds;

	public ProdottoModel() {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	
	public ProdottoModel(DataSource ds) {
		this.ds = ds;
	}

	private static final String TABLE_NAME = "prodotto";

	public synchronized int doSave(ProdottoBean product) throws SQLException {
		if(product==null) throw new IllegalArgumentException();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int id = -1;
		String insertSQL = "INSERT INTO prodotto(titolo, autore, descrizione, dataCreazione, prezzo, dimensione, opera, numeroBrani,"
				+ "durata, editore, numeroPagine, categoria, verificato, disponibilita, genere, motivazione)"
				+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		connection = ds.getConnection();
		preparedStatement = connection.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS);


		preparedStatement.setString(1, product.getTitolo());
		preparedStatement.setString(2, product.getAutore());
		preparedStatement.setString(3, product.getDescrizione());
		preparedStatement.setString(4, product.getDataCreazione());
		preparedStatement.setDouble(5, product.getPrezzo());
		preparedStatement.setString(6, product.getDimensione());
		preparedStatement.setString(7, product.getOpera());
		preparedStatement.setInt(8, product.getNumeroBrani());
		preparedStatement.setString(9, product.getDurata());
		preparedStatement.setString(10, product.getEditore());
		preparedStatement.setInt(11, product.getNumeroPagine());
		preparedStatement.setString(12, product.getCategoria());
		preparedStatement.setInt(13, product.getVerificato());
		preparedStatement.setInt(14, product.getDisponibilita());
		preparedStatement.setString(15, product.getGenere());
		preparedStatement.setString(16, product.getMotivazione());

		

	
			try {

				preparedStatement.executeUpdate();
				ResultSet rs = preparedStatement.getGeneratedKeys();
				rs.next();
				id = rs.getInt(1);

			} finally {
				try {
					if (preparedStatement != null)
						preparedStatement.close();
				} finally {
					if (connection != null)
						connection.close();
				}
			}
			 
		
		return id;
	}


	public synchronized ProdottoBean doRetrieveByKey(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(code<0) throw new IllegalArgumentException();
		ProdottoBean bean = null;

		String selectSQL = "SELECT * FROM " + ProdottoModel.TABLE_NAME + " WHERE CODICE = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, code);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				bean = new ProdottoBean();
				bean.setCodice(rs.getInt("codice"));
				bean.setTitolo(rs.getString("titolo"));
				bean.setAutore(rs.getString("autore"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setDataCreazione(rs.getString("dataCreazione"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setDimensione(rs.getString("dimensione"));
				String url = "imm/" + rs.getString("opera");
				bean.setOpera(url);
				bean.setNumeroBrani(rs.getInt("numeroBrani"));
				bean.setDurata(rs.getString("durata"));
				bean.setEditore(rs.getString("editore"));
				bean.setNumeroPagine(rs.getInt("numeroPagine"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setVerificato(rs.getInt("verificato"));
				bean.setGenere(rs.getString("genere"));
				bean.setDisponibilita(rs.getInt("disponibilita"));
				bean.setMotivazione(rs.getString("motivazione"));
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	}

	public synchronized ArrayList<ProdottoBean> doRetrieveByVerificato() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ArrayList<ProdottoBean> products = new ArrayList<ProdottoBean>();

		String selectSQL = "SELECT * FROM prodotto" + " WHERE verificato = 0";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProdottoBean bean = new ProdottoBean();
				bean.setCodice(rs.getInt("codice"));
				bean.setTitolo(rs.getString("titolo"));
				bean.setAutore(rs.getString("autore"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setDataCreazione(rs.getString("dataCreazione"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setDimensione(rs.getString("dimensione"));
				String url = "imm/" + rs.getString("opera");
				bean.setOpera(url);
				bean.setNumeroBrani(rs.getInt("numeroBrani"));
				bean.setDurata(rs.getString("durata"));
				bean.setEditore(rs.getString("editore"));
				bean.setNumeroPagine(rs.getInt("numeroPagine"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setVerificato(rs.getInt("verificato"));
				bean.setGenere(rs.getString("genere"));
				bean.setDisponibilita(rs.getInt("disponibilita"));
				bean.setMotivazione(rs.getString("motivazione"));
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}

	public synchronized boolean doDelete(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(code<0) throw new IllegalArgumentException();
		int result = 0;

		String deleteSQL = "DELETE FROM " + ProdottoModel.TABLE_NAME + " WHERE CODICE = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, code);

			result = preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return (result != 0);
	}

	

	public synchronized ArrayList<ProdottoBean> doRetrieveAllByType(String type, String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if (type==null || order==null) throw new IllegalArgumentException();
		ArrayList<ProdottoBean> products = new ArrayList<ProdottoBean>();

		String selectSQL = "SELECT * FROM " + ProdottoModel.TABLE_NAME + " WHERE categoria=? && verificato=1";
		selectSQL += " ORDER BY " + order;

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, type);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProdottoBean bean = new ProdottoBean();

				bean.setCodice(rs.getInt("codice"));
				bean.setTitolo(rs.getString("titolo"));
				bean.setAutore(rs.getString("autore"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setDataCreazione(rs.getString("dataCreazione"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setDimensione(rs.getString("dimensione"));
				String url = "imm/" + rs.getString("opera");
				bean.setOpera(url);
				bean.setNumeroBrani(rs.getInt("numeroBrani"));
				bean.setDurata(rs.getString("durata"));
				bean.setEditore(rs.getString("editore"));
				bean.setNumeroPagine(rs.getInt("numeroPagine"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setVerificato(rs.getInt("verificato"));
				bean.setGenere(rs.getString("genere"));
				bean.setDisponibilita(rs.getInt("disponibilita"));
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}

	public synchronized ArrayList<ProdottoBean> doRetrieveByUser(String user) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(user==null) throw new IllegalArgumentException();
		ArrayList<ProdottoBean> products = new ArrayList<ProdottoBean>();

		String selectSQL = "SELECT * FROM prodotto" + " WHERE autore=?";
		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, user);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProdottoBean bean = new ProdottoBean();

				bean.setCodice(rs.getInt("codice"));
				bean.setTitolo(rs.getString("titolo"));
				bean.setAutore(rs.getString("autore"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setDataCreazione(rs.getString("dataCreazione"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setDimensione(rs.getString("dimensione"));
				String url = "imm/" + rs.getString("opera");
				bean.setOpera(url);
				bean.setNumeroBrani(rs.getInt("numeroBrani"));
				bean.setDurata(rs.getString("durata"));
				bean.setEditore(rs.getString("editore"));
				bean.setNumeroPagine(rs.getInt("numeroPagine"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setVerificato(rs.getInt("verificato"));
				bean.setGenere(rs.getString("genere"));
				bean.setDisponibilita(rs.getInt("disponibilita"));
				products.add(bean);
			}
		}

		finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}

	public synchronized ArrayList<ProdottoBean> searchByArtist(String user, String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(user==null || order==null) throw new IllegalArgumentException();
		ArrayList<ProdottoBean> products = new ArrayList<ProdottoBean>();

		String selectSQL = "SELECT * FROM prodotto" + " WHERE verificato=1 && UPPER(autore) LIKE UPPER(?)";
		selectSQL += " ORDER BY " + order;
		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, "%" + user + "%");
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProdottoBean bean = new ProdottoBean();

				bean.setCodice(rs.getInt("codice"));
				bean.setTitolo(rs.getString("titolo"));
				bean.setAutore(rs.getString("autore"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setDataCreazione(rs.getString("dataCreazione"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setDimensione(rs.getString("dimensione"));
				String url = "imm/" + rs.getString("opera");
				bean.setOpera(url);
				bean.setNumeroBrani(rs.getInt("numeroBrani"));
				bean.setDurata(rs.getString("durata"));
				bean.setEditore(rs.getString("editore"));
				bean.setNumeroPagine(rs.getInt("numeroPagine"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setVerificato(rs.getInt("verificato"));
				bean.setGenere(rs.getString("genere"));
				bean.setDisponibilita(rs.getInt("disponibilita"));
				products.add(bean);
			}
		}

		finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}

	public synchronized void confermaProdotto(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(code<0) throw new IllegalArgumentException();
		String selectSQL = "UPDATE prodotto set verificato=1 where codice=?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, code);

			preparedStatement.executeUpdate();
		}

		finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}
	
	public synchronized void rifiutaProdotto(int code, String motivazione) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(code<0 || motivazione == null) throw new IllegalArgumentException();
		String selectSQL = "UPDATE prodotto set verificato=0, motivazione=? where codice=?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(2, code);
			preparedStatement.setString(1, motivazione);

			preparedStatement.executeUpdate();
		}

		finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}
	
	public synchronized ArrayList<ProdottoBean> doRetrieveByArtistVerificato(String user) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(user==null) throw new IllegalArgumentException();
		ArrayList<ProdottoBean> products = new ArrayList<ProdottoBean>();

		String selectSQL = "SELECT * FROM prodotto" + " WHERE verificato = 0 && autore=?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, user);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProdottoBean bean = new ProdottoBean();
				bean.setCodice(rs.getInt("codice"));
				bean.setTitolo(rs.getString("titolo"));
				bean.setAutore(rs.getString("autore"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setDataCreazione(rs.getString("dataCreazione"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setDimensione(rs.getString("dimensione"));
				String url = "imm/" + rs.getString("opera");
				bean.setOpera(url);
				bean.setNumeroBrani(rs.getInt("numeroBrani"));
				bean.setDurata(rs.getString("durata"));
				bean.setEditore(rs.getString("editore"));
				bean.setNumeroPagine(rs.getInt("numeroPagine"));
				bean.setCategoria(rs.getString("categoria"));
				bean.setVerificato(rs.getInt("verificato"));
				bean.setGenere(rs.getString("genere"));
				bean.setDisponibilita(rs.getInt("disponibilita"));
				bean.setMotivazione(rs.getString("motivazione"));
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	}
	

}
