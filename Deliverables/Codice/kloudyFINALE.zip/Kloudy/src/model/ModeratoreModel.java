package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import bean.ModeratoreBean;

public class ModeratoreModel {
	private  DataSource ds;

	public ModeratoreModel(){
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	public ModeratoreModel(DataSource ds){this.ds=ds;}
	
	
	public synchronized ModeratoreBean doRetrieveByKey(String uname) throws SQLException {
		if (uname == null) throw new IllegalArgumentException();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ModeratoreBean user = new ModeratoreBean();

		String selectSQL = "SELECT * FROM moderatore" + " WHERE nickname = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, uname);

			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				user.setNickname(rs.getString("nickname"));
				user.setPwd(rs.getString("pwd"));
				
			}
				
			}
	
		 finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return user;
	}
}
