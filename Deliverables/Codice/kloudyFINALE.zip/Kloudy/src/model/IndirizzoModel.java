package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import bean.IndirizzoBean;

/**
 * Classe che gestisce la transazione degli indirizzi
 *
 */
public class IndirizzoModel {

	private  DataSource ds;

		public IndirizzoModel() {
			try {
				Context initCtx = new InitialContext();
				Context envCtx = (Context) initCtx.lookup("java:comp/env");

				ds = (DataSource) envCtx.lookup("jdbc/storage");

			} catch (NamingException e) {
				System.out.println("Error:" + e.getMessage());
			}
		}
		
		public IndirizzoModel(DataSource ds) {
			this.ds = ds;
		}


	public synchronized int doSave(IndirizzoBean indirizzo) throws SQLException {

		if(indirizzo == null) throw new IllegalArgumentException();
		Connection connection = null;
		int id = -1;
		PreparedStatement preparedStatement = null;
		String insertSQL = "INSERT INTO indirizzo(indirizzo,citta,cap,telefono,nome,cognome,utente,provincia)"
				+ " VALUES(?,?,?,?,?,?,?,?)";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS);

			preparedStatement.setString(1, indirizzo.getIndirizzo());
			preparedStatement.setString(2, indirizzo.getCitta());
			preparedStatement.setInt(3, indirizzo.getCap());
			preparedStatement.setString(4, indirizzo.getTelefono());
			preparedStatement.setString(5, indirizzo.getNome());
			preparedStatement.setString(6, indirizzo.getCognome());
			preparedStatement.setString(7, indirizzo.getCliente());
			preparedStatement.setString(8, indirizzo.getProvincia());

			preparedStatement.executeUpdate();
			ResultSet rs = preparedStatement.getGeneratedKeys();
			rs.next();
			id = rs.getInt(1);

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return id;
	}

	/**
	 * Metodo che legge gli indirizzi dal database
	 * 
	 * @param nickname
	 * @pre Nickname != null
	 * @post Ritorna indirizzi.size() > 0 se il cliente ha degli indirizzi
	 *       memorizzati || Ritorna indirizzi.size() == 0 se non ci sono indirizzi
	 *       memorizzati per il cliente
	 * @return indirizzi
	 * @return null
	 * @throws SQLException
	 */
	public synchronized ArrayList<IndirizzoBean> doRetrieveAllByUsername(String nickname) throws SQLException {
		if (nickname == null) {
			throw new IllegalArgumentException();
		}

		ArrayList<IndirizzoBean> indirizzi = new ArrayList<IndirizzoBean>();

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String insertSQLProd = "SELECT * FROM indirizzo" + " WHERE utente = ?";
		System.out.println(insertSQLProd);

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(insertSQLProd);
			preparedStatement.setString(1, nickname);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				IndirizzoBean bean = new IndirizzoBean();
				bean.setCodice(rs.getInt("codice"));
				bean.setCap(rs.getInt("cap"));
				bean.setCitta(rs.getString("citta"));
				bean.setIndirizzo(rs.getString("indirizzo"));
				bean.setProvincia(rs.getString("provincia"));
				bean.setTelefono(rs.getString("Telefono"));
				bean.setNome(rs.getString("nome"));
				bean.setCognome(rs.getString("cognome"));
				bean.setCliente(rs.getString("utente"));
				indirizzi.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return indirizzi;
	}


	public synchronized void rimuoviIndirizzo(int codice) throws SQLException {
		if (codice < 0) {
			throw new IllegalArgumentException();
		}
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String insertSQL = "DELETE FROM indirizzo"+ " WHERE CODICE = ?";
		try {
			try {
				connection = ds.getConnection();
				preparedStatement = connection.prepareStatement(insertSQL);
				preparedStatement.setInt(1, codice);
				preparedStatement.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}
	

	public synchronized IndirizzoBean doRetrieveByKey(int codice) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		IndirizzoBean indirizzo = null;
		if(codice<0) throw new IllegalArgumentException();
		String selectSQL = "SELECT * FROM indirizzo WHERE codice = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, codice);

			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				indirizzo = new IndirizzoBean();
				indirizzo.setCodice(rs.getInt("codice"));
				indirizzo.setCliente(rs.getString("utente"));
				indirizzo.setNome(rs.getString("nome"));
				indirizzo.setCognome(rs.getString("cognome"));
				indirizzo.setIndirizzo(rs.getString("indirizzo"));
				indirizzo.setCitta(rs.getString("citta"));
				indirizzo.setCap(rs.getInt("cap"));
				indirizzo.setTelefono(rs.getString("telefono"));
				indirizzo.setProvincia(rs.getString("provincia"));
			
			}
				
			}
	
		 finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return indirizzo;
	}

}
