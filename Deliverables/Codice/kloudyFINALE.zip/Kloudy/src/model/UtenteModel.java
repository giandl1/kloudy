package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import bean.IndirizzoBean;
import bean.UtenteBean;

public class UtenteModel {

	private  DataSource ds;

	public UtenteModel() {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	
	public UtenteModel(DataSource ds) {
		this.ds = ds;
	}

	private static final String TABLE_NAME = "utente";

	public synchronized void doSave(UtenteBean utente, IndirizzoBean indirizzo) throws SQLException {
		if(utente == null || indirizzo == null) throw new IllegalArgumentException();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String insertSQL = "INSERT INTO utente VALUES(?, ?, ?, ?, ?, ?, ?)";
		String indirizzoSQL = "INSERT INTO indirizzo(indirizzo,citta,cap,telefono,nome,cognome,utente,provincia)"
				+ " VALUES(?,?,?,?,?,?,?,?)";
		
		connection = ds.getConnection();
		preparedStatement = connection.prepareStatement(insertSQL);
		PreparedStatement prepared2 = connection.prepareStatement(indirizzoSQL);
				
			preparedStatement.setString(5, utente.getPiva());
			preparedStatement.setString(3, utente.getEmail());
			preparedStatement.setString(4, utente.getPassword());
			preparedStatement.setString(1, utente.getNome());
			preparedStatement.setString(2, utente.getCognome());
			preparedStatement.setString(6, utente.getUsername());
			preparedStatement.setString(7, utente.getCategoriaUtente());

			prepared2.setString(1, indirizzo.getIndirizzo());
			prepared2.setString(2, indirizzo.getCitta());
			prepared2.setInt(3, indirizzo.getCap());
			prepared2.setString(4, indirizzo.getTelefono());
			prepared2.setString(5, indirizzo.getNome());
			prepared2.setString(6, indirizzo.getCognome());
			prepared2.setString(7, indirizzo.getCliente());
			prepared2.setString(8, indirizzo.getProvincia());
		
		try {
			
			preparedStatement.executeUpdate();
			prepared2.executeUpdate();
			//connection.commit();
			
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
	}

	
	

	public synchronized UtenteBean doRetrieveByKey(String uname) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(uname==null) throw new IllegalArgumentException();
		UtenteBean user = null;
		String selectSQL = "SELECT * FROM " + UtenteModel.TABLE_NAME + " WHERE nickname = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, uname);

			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				user = new UtenteBean();
				user.setUsername(rs.getString("nickname"));
				user.setPassword(rs.getString("pw"));
				user.setNome(rs.getString("nome"));
				user.setCognome(rs.getString("cognome"));
				user.setCategoriaUtente(rs.getString("ruolo"));
				user.setEmail(rs.getString("email"));
				user.setPiva(rs.getString("piva"));
			}
				
			}
	
		 finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return user;
	}
	
	
	
	
	public synchronized boolean countMail(UtenteBean user) throws SQLException
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(user == null) throw new IllegalArgumentException();
		String query = "select count(*) as numEmail from utente where email=?";
		
		connection = ds.getConnection();
		preparedStatement = connection.prepareStatement(query);
		preparedStatement.setString(1, user.getEmail());
		ResultSet rs = preparedStatement.executeQuery();
		if(rs.next()) {
			int count = rs.getInt("numEmail");
			if(count==1)
				return true;
		}
		return false;
		
	}
	
	
	
	
	public synchronized ArrayList<UtenteBean> doRetrieveAll() throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ArrayList<UtenteBean> users = new ArrayList<UtenteBean>();

		String selectSQL = "SELECT * FROM utente";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
	

			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				UtenteBean user = new UtenteBean();
				user.setUsername(rs.getString("nickname"));
				user.setPassword(rs.getString("pw"));
				user.setNome(rs.getString("nome"));
				user.setCognome(rs.getString("cognome"));
				user.setCategoriaUtente(rs.getString("ruolo"));
				user.setEmail(rs.getString("email"));
				user.setPiva(rs.getString("piva"));
				users.add(user);
			}
				
			}
	
		 finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return users;
	}
		
		
	


	public synchronized void doDelete(String nickname) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(nickname == null) throw new IllegalArgumentException();
	

		String deleteSQL = "DELETE FROM utente WHERE nickname = ?";

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(deleteSQL);
			preparedStatement.setString(1, nickname);

			preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return;
	}
}
