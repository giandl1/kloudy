package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import bean.ProdottoOrdineBean;

public class ProdottoOrdineModel {

	private  DataSource ds;


		public ProdottoOrdineModel() {
			try {
				Context initCtx = new InitialContext();
				Context envCtx = (Context) initCtx.lookup("java:comp/env");

				ds = (DataSource) envCtx.lookup("jdbc/storage");

			} catch (NamingException e) {
				System.out.println("Error:" + e.getMessage());
			}
		}
		
		public ProdottoOrdineModel(DataSource ds) {
			this.ds = ds;
		}
	
	
	public synchronized int doSave(ProdottoOrdineBean prod, int ordine) throws SQLException {
		if(prod == null || ordine<0) throw new IllegalArgumentException();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		//System.out.println(order.getId());
		String insertSQL = "INSERT INTO prodottoordine(titolo, autore, prezzo, codiceOrdine, opera, quantita, id, categoria) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		int id;
		connection = ds.getConnection();
		preparedStatement = connection.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS);

		preparedStatement.setString(1, prod.getTitolo());
		preparedStatement.setString(2, prod.getAutore());
		preparedStatement.setDouble(3, prod.getPrezzo());
		preparedStatement.setInt(4, ordine);
		preparedStatement.setString(5, prod.getOpera());
		preparedStatement.setInt(6, prod.getQuantita());
		preparedStatement.setInt(7,  prod.getId());
		preparedStatement.setString(8, prod.getCategoria());
		PreparedStatement alterQuantity = connection
				.prepareStatement("UPDATE prodotto SET disponibilita = disponibilita - ? WHERE codice = ?");
		alterQuantity.setInt(1, prod.getQuantita());
		alterQuantity.setInt(2, prod.getId());

		try {

			preparedStatement.executeUpdate();
			ResultSet rs = preparedStatement.getGeneratedKeys();
			rs.next();
			id = rs.getInt(1);
			alterQuantity.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return id;

	}
	
	
	public synchronized ArrayList<ProdottoOrdineBean> doRetrieveByOrdine(int codice) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(codice < 0) throw new IllegalArgumentException();
		ArrayList<ProdottoOrdineBean> products = new ArrayList<ProdottoOrdineBean>();

		String selectSQL = "SELECT * FROM prodottoordine where codiceOrdine=?";



		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, codice);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ProdottoOrdineBean bean = new ProdottoOrdineBean();

				bean.setCodice(rs.getInt("codice"));
				bean.setTitolo(rs.getString("titolo"));
				bean.setAutore(rs.getString("autore"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setQuantita(rs.getInt("quantita"));
				bean.setOpera(rs.getString("opera"));
				bean.setCodiceOrdine(rs.getInt("codiceOrdine"));
				bean.setId(rs.getInt("id"));
				bean.setCategoria(rs.getString("categoria"));
				products.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return products;
	} 
	
	
	
	public synchronized ProdottoOrdineBean doRetrieveByKey(int codice) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(codice <0) throw new IllegalArgumentException();
		ProdottoOrdineBean bean = null;

		String selectSQL = "SELECT * FROM prodottoordine where codice=?";


		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, codice);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				bean = new ProdottoOrdineBean();

				bean.setCodice(rs.getInt("codice"));
				bean.setTitolo(rs.getString("titolo"));
				bean.setAutore(rs.getString("autore"));
				bean.setPrezzo(rs.getDouble("prezzo"));
				bean.setQuantita(rs.getInt("quantita"));
				bean.setOpera(rs.getString("opera"));
				bean.setCodiceOrdine(rs.getInt("codiceOrdine"));
				bean.setId(rs.getInt("id"));
				bean.setCategoria(rs.getString("categoria"));
	
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	} 
	
	
	
	
	
}

