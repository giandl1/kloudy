package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import bean.OrdineBean;

public class OrdineModel {

	private  DataSource ds;

	public OrdineModel(){
		try {
		Context initCtx = new InitialContext();
		Context envCtx = (Context) initCtx.lookup("java:comp/env");

		ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
		System.out.println("Error:" + e.getMessage());
		}
		}
		public OrdineModel(DataSource ds){ this.ds = ds;}

	private static final String TABLE_NAME = "ordine";

	public synchronized int doSave(OrdineBean order) throws SQLException {
		if(order==null) throw new IllegalArgumentException();
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String insertSQL = "INSERT INTO " + OrdineModel.TABLE_NAME
				+ "(dataOrdine, cliente, totale, stato, tracking, corriere, indirizzo, carta, artista) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

		connection = ds.getConnection();
		preparedStatement = connection.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS);
		java.sql.Date sd = new java.sql.Date(order.getDataOrdine().getTime());
		preparedStatement.setDate(1, sd);
		preparedStatement.setString(2, order.getCliente());
		preparedStatement.setDouble(3, order.getTotale());
		preparedStatement.setString(4, order.getStato());
		preparedStatement.setString(5, order.getTracking());
		preparedStatement.setString(6, order.getCorriere());
		preparedStatement.setInt(7, order.getIndirizzo());
		preparedStatement.setInt(8, order.getCarta());
		preparedStatement.setString(9, order.getArtista());


		try {

			preparedStatement.executeUpdate();
			ResultSet rs = preparedStatement.getGeneratedKeys();
			rs.next();
			int id = rs.getInt(1);
			//System.out.println(id);
			return id;
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}

	}

	

	public synchronized ArrayList<OrdineBean> doRetrieveAll(String cliente, String ordinamento) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(cliente==null || ordinamento == null) throw new IllegalArgumentException();
		ArrayList<OrdineBean> orders = new ArrayList<OrdineBean>();

		String selectSQL = "SELECT * FROM " + OrdineModel.TABLE_NAME + " where cliente = ?";

		if (ordinamento != null && !ordinamento.equals("")) {
			selectSQL += " ORDER BY " + ordinamento;
		}

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, cliente);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				OrdineBean order = new OrdineBean();

				order.setId(rs.getInt("codice"));
				order.setCliente(rs.getString("cliente"));
				order.setDataOrdine(rs.getDate("dataOrdine"));
				order.setTotale(rs.getDouble("totale"));
				order.setCarta(rs.getInt("carta"));
				order.setIndirizzo(rs.getInt("indirizzo"));
				order.setStato(rs.getString("stato"));
				order.setTracking(rs.getString("tracking"));
				order.setCorriere(rs.getString("corriere"));
				order.setArtista(rs.getString("artista"));
				orders.add(order);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return orders;
	}

	
	
	public synchronized ArrayList<OrdineBean> doRetrieveByArtist(String artist) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(artist==null) throw new IllegalArgumentException();
		ArrayList<OrdineBean> orders = new ArrayList<OrdineBean>();

		String selectSQL = "SELECT * FROM ordine" + " where artista = ?";

	

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, artist);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				OrdineBean order = new OrdineBean();

				order.setId(rs.getInt("codice"));
				order.setCliente(rs.getString("cliente"));
				order.setDataOrdine(rs.getDate("dataOrdine"));
				order.setTotale(rs.getDouble("totale"));
				order.setCarta(rs.getInt("carta"));
				order.setIndirizzo(rs.getInt("indirizzo"));
				order.setStato(rs.getString("stato"));
				order.setTracking(rs.getString("tracking"));
				order.setCorriere(rs.getString("corriere"));
				order.setArtista(rs.getString("artista"));
				orders.add(order);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return orders;
	}
	
	public synchronized OrdineBean doRetrieveByKey(int codice) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(codice<0) throw new IllegalArgumentException();
		OrdineBean order = null;

		String selectSQL = "SELECT * FROM ordine" + " where codice = ?";

	

		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, codice);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				order = new OrdineBean();

				order.setId(rs.getInt("codice"));
				order.setCliente(rs.getString("cliente"));
				order.setDataOrdine(rs.getDate("dataOrdine"));
				order.setTotale(rs.getDouble("totale"));
				order.setCarta(rs.getInt("carta"));
				order.setIndirizzo(rs.getInt("indirizzo"));
				order.setStato(rs.getString("stato"));
				order.setTracking(rs.getString("tracking"));
				order.setCorriere(rs.getString("corriere"));
				order.setArtista(rs.getString("artista"));
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return order;
	}
	
	public synchronized void setInSpedizione(int ordine, String corriere, String tracking) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(ordine < 0 || corriere == null || tracking == null) throw new IllegalArgumentException();

		String selectSQL = "update ordine set stato = 'In spedizione', corriere = ?, tracking = ? where codice = ?";



		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, corriere);
			preparedStatement.setString(2, tracking);
			preparedStatement.setInt(3, ordine);

			 preparedStatement.executeUpdate();


		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
	}
	
	public synchronized void setSpedito(int codice) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		if(codice<0) throw new IllegalArgumentException();

		String selectSQL = "update ordine set stato = 'Spedito' where codice = ?";



		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, codice);

			 preparedStatement.executeUpdate();


		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		
	}

}