//Jquery animazione immagine dettagli prodotto

$(document).ready(function(){
	$("#img1").hover(zoomIn, zoomOut);
});

function zoomIn(){
	$("#img1").stop().animate({'width' : '50%'}, 200).css({
		'border' : 'solid 1px #000',
		'border-radius' : '0px 6px 10px rgba(0,0,0,.8)',
		'box-shadow' : '0px 6px 10px rgba(0,0,0,.8)',
		'z-index' : '2'
	});
	
}

function zoomOut(){
	$("#img1").stop().animate({'width' : '25%'}, 200).css({
		'border' : 'solid 0px #000',
		'border-radius' : '0px',
		'box-shadow' : '0px 0px 0px rgba(0,0,0,.8)',
		'z-index' : '1'
		
	});
}
