$(document).ready(function() {
	$(".orderButton").click(function(event){  //AJAX in JQuery
		
		var buttonID = event.target.id;
		
	$.get('loadProducts', {"buttonid": buttonID },  function(resp) {
		
		printProducts(resp);
		
	}).fail(function(){
		alert("Request failed");
	});	
	
});
});

function printProducts(json)
{
	var output = "";
	$("#resultDiv").empty().append("");
	output+=
	'<table class ="blueTable">'
	+	'<tr>'
	+		'<th></th>'
	+		'<th class="hide">Codice</th>'
	+		'<th class="hide">Marca</th>'
	+		'<th class="hide">Modello</th>'
	+		'<th class="hide">Prezzo</th>'
	+		'<th class="hide">Disponibilità</th>'
	+		'<th></th>'
	+	'</tr>';
	
	$.each(json, function(i,product){
		output+='<tr>'
			+ '<td><img src="'+ product.immagine + '"></td>'
			+ '<td class="hide">' + product.code + '</td>'
			+ '<td>' + product.brand + '</td>'		
			+ '<td class="hide">' + product.modello + '</td>'			
			+ '<td>' + product.price + '€</td>'			
			+ '<td class="hide">' + product.quantity + '</td>'
			+ '<td>' 
			+ '<form action="editProduct"> <input type="hidden" name="action" value="delete"> <input type="hidden" name="id" value="' + product.code + '"> <input type="submit" value="Elimina prodotto"> </form>'
			+ '<form action="editProduct"> <input type="hidden" name="action" value ="quantity"> <input type="hidden" name="id" value="' + product.code + '"> <input type="number" name="quantita" min="0" value="0"> <input type="submit" value="Modifica disponibilità"></form>'
			+ '</td>'
			+ '</tr>';
	});
	$("#resultDiv").append(output);



}