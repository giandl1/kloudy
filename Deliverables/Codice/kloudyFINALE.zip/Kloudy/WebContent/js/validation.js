
function formValidation()
{
	var username = document.registration.username.value;
	var password = document.registration.password.value;
	var nome = document.registration.nome.value;
	var cognome = document.registration.cognome.value;
	//var indirizzo = document.registration.indirizzo.value;
	//var citta = document.registration.citta.value;
	//var provincia = document.registration.provincia.value;
	var email = document.registration.email.value;
	//var telefono = document.registration.telefono.value;
	var val1 = ValidateEmail(email);
	var val2 = ValidateUsername(username);
	var val3 = ValidatePassword(password);
	var val4 = ValidateNome(nome);
	var val5 = ValidateCognome(cognome);
	if(val1==false || val2==false || val3==false || val4==false || val5==false)
		return false;
	return true;

}

function ValidateNome(nome)
{
	var len = nome.length;
	if (len<2 || len>30){
		document.getElementById("nomeError").innerHTML = "Il nome dev'essere compreso tra 2 e 30 caratteri";
		return false;	
	}
	else
	return true;
}

function ValidateCognome(nome)
{
	var len = nome.length;
	if (len<2 || len>30){
		document.getElementById("cognomeError").innerHTML = "Il cognome dev'essere compreso tra 2 e 30 caratteri";
		return false;	
	}
	else
	return true;
}

function ValidateEmail(email)
{
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(email.match(mailformat))
		return true;
else
{
	document.getElementById("emailError").innerHTML = "Email non valida";
	return false;
}
}


function ValidateUsername(username)
{
	var len = username.length;
	if (len<6 || len>30){
		document.getElementById("usernameError").innerHTML = "Username dev'essere compreso tra 6 e 30 caratteri";
		return false;	
	}
	else
	return true;
}

function ValidateEditPsw(){
	var password = document.editpassw.password.value;
	var repeat = document.editpassw.repeatpsw.value;
	var val1 = ValidatePassword(password);
	var val2 = ValidateRepeat(password, repeat);
	if (val1==false || val2==false){
		return false;
	}
	else
	return true;
}

function ValidatePassword(password)
{
	var len = password.length;
	if (len<6 || len>30){
		document.getElementById("passwordError").innerHTML = "La Password dev'essere compresa tra 8 e 30 caratteri";
		return false;	
	}
	else{
	return true; }
}

function ValidateRepeat(password, repeat)
{
	if(password==repeat)
		return true;
	else{
		document.getElementById("repeatError").innerHTML = "La Password inserita non corrisponde";
		return false;
	}
}

function ValidateTelefono(telefono)
{
	var numbers = /^[0-9]+$/;
	if((telefono.match(numbers)) && (telefono.length == 10)){
		return true;
	}
	else{
		document.getElementById("telefonoError").innerHTML = "Numero di telefono non valido";
		return false;
	}
}




